from setuptools import setup

if __name__ == "__main__":
    setup()

install_requires = [
    'pandas',
    'NOBM',
    'numpy',
    'matplot',
    'OMADS',
    'genericpath',
    'math',
    'enum'
]
